﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventosModelos;

namespace EventosAcd.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AsistentesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AsistentesController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Asistentes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Asistente>>> GetAsistente()
        {
            var asistente = await _context.Asistentes
        .Include(e => e.Evento)
        .Select(e => new
        {
            e.Id,
            e.NombreAsistente,
            EventoId = e.EventoId,
            Evento = e.Evento == null ? null : new { e.Evento.Id, e.Evento.Nombre },
        })
        .ToListAsync();

            return Ok(asistente);
        }

        // GET: api/Asistentes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Asistente>> GetAsistente(int id)
        {
            var asistente = await _context.Asistentes
            .Include(e => e.Evento)
            .ThenInclude(ev => ev.Espacio)  
            .Include(e => e.Evento)
            .ThenInclude(ev => ev.Ponente)
            .Where(e => e.Id == id)
        .Select(e => new Asistente
        {
            Id = e.Id,
            NombreAsistente = e.NombreAsistente,
            EventoId = e.EventoId,
            Evento = e.Evento == null ? null : new Evento
            {
                Id = e.Evento.Id,
                Nombre = e.Evento.Nombre,
                Descripcion = e.Evento.Descripcion,
                Fecha = e.Evento.Fecha,
                HorarioInicio = e.Evento.HorarioInicio,
                EspacioId = e.Evento.EspacioId,
                PonenteId = e.Evento.PonenteId,
                Espacio = e.Evento.Espacio == null ? null : new Espacio
                {
                    Id = e.Evento.Espacio.Id,
                    Nombre = e.Evento.Espacio.Nombre,
                    Horario = e.Evento.Espacio.Horario
                },
                Ponente = e.Evento.Ponente == null ? null : new Ponente
                {
                    Id = e.Evento.Ponente.Id,
                    Nombre = e.Evento.Ponente.Nombre,
                    Apellido = e.Evento.Ponente.Apellido,
                    Especialidad = e.Evento.Ponente.Especialidad,
                    Institucion = e.Evento.Ponente.Institucion
                }
            }
        })
        .FirstOrDefaultAsync();


            if (asistente == null)
            {
                return NotFound();
            }

            // Devolvemos el evento con los datos relacionados
            return Ok(asistente);
        }

            // PUT: api/Asistentes/5
            // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
            [HttpPut("{id}")]
        public async Task<IActionResult> PutAsistente(int id, Asistente asistente)
        {
            if (id != asistente.Id)
            {
                return BadRequest();
            }

            _context.Entry(asistente).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AsistenteExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Asistentes
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Asistente>> PostAsistente(Asistente asistente)
        {
            _context.Asistentes.Add(asistente);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetAsistente", new { id = asistente.Id }, asistente);
        }

        // DELETE: api/Asistentes/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAsistente(int id)
        {
            var asistente = await _context.Asistentes.FindAsync(id);
            if (asistente == null)
            {
                return NotFound();
            }

            _context.Asistentes.Remove(asistente);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool AsistenteExists(int id)
        {
            return _context.Asistentes.Any(e => e.Id == id);
        }
    }
}
