﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using EventosModelos;

    public class AppDbContext : DbContext
    {
        public AppDbContext (DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<EventosModelos.Asistente> Asistentes { get; set; } = default!;

        public DbSet<EventosModelos.Certificado> Certificados { get; set; } = default!;

        public DbSet<EventosModelos.Espacio> Espacios { get; set; } = default!;

        public DbSet<EventosModelos.Evento> Eventos { get; set; } = default!;

        public DbSet<EventosModelos.Inscripcion> Inscripciones { get; set; } = default!;

        public DbSet<EventosModelos.Ponente> Ponentes { get; set; } = default!;

            public DbSet<EventosModelos.Pago> Pagos { get; set; } = default!;
        
         

      
    }
