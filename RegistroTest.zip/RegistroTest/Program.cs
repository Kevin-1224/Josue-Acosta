﻿using EventoApiConsumer;
using EventosModelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistroTest
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ProbarEvento();
            //ProbarPonente();
            //ProbarAsistente();
            //ProbarCertificado();
            //ProbarEspacio();
            //ProbarInscripcion();
            //ProbarPago();
            Console.ReadLine();
        }

        private static void ProbarEvento()
        {
            Crud<Evento>.EndPoint = "https://localhost:7216/api/Eventos";

            // crear un objeto de la clase Evento
            var evento = Crud<Evento>.Create(new Evento
            {
                Id = 0,   // para crear un registro nuevo
                Nombre = "Curso Programacion",
                Descripcion = "Curso de Programacion en C#",
                Fecha = "2023-10-01",
                HorarioInicio = "08:00",
                EspacioId = 1, // id del espacio
                PonenteId = 1,

            });

            // actualizar el Evento
            evento.Nombre = "Curso de Programacion";
            Crud<Evento>.Update(evento.Id, evento);

            // obtener todos los cursos
            var cursos1 = Crud<Evento>.GetAll();

            foreach (var l in cursos1)
            {
                Console.WriteLine($"Codigo: {l.Id}, Nombre: {l.Nombre}, Descripcion: {l.Descripcion}, Fecha: {l.Fecha}, HoraIncio: {l.HorarioInicio}");
            }
        }

        private static void ProbarPonente()
        {
            Crud<Ponente>.EndPoint = "https://localhost:7216/api/Ponentes";

            // crear un objeto de la clase Evento
            var ponente = Crud<Ponente>.Create(new Ponente
            {
                Id = 0,   // para crear un registro nuevo
                Nombre = "Marci",
                Apellido = "Paz",
                Especialidad = "Programacion",
                Institucion = "Universidad Nacional"
            });

            // actualizar el Evento
            ponente.Nombre = "Marco";
            Crud<Ponente>.Update(ponente.Id,ponente);

            // obtener todos los cursos
            var cursos1 = Crud<Ponente>.GetAll();

            foreach (var l in cursos1)
            {
                Console.WriteLine($"Codigo: {l.Id}, Nombre: {l.Nombre}, Apellido: {l.Apellido}, Especialidad: {l.Especialidad}, Institucion: {l.Institucion}");
            }
        }

        private static void ProbarAsistente()
        {
            Crud<Asistente>.EndPoint = "https://localhost:7216/api/Asistentes";

            // Crear un objeto de la clase Asistente
            var asistente = Crud<Asistente>.Create(new Asistente
            {
                Id = 0,   // para crear un registro nuevo
                NombreAsistente = "Veronica",
                EventoId = 1
            });

            // Actualizar el Asistente
            asistente.NombreAsistente = "Veronica Gomez";
            Crud<Asistente>.Update(asistente.Id, asistente);

            // Obtener todos los asistentes
            var asistentes = Crud<Asistente>.GetAll();

            foreach (var a in asistentes)
            {
                Console.WriteLine($"Codigo: {a.Id}, Nombre: {a.NombreAsistente}, EventoId: {a.EventoId}");
            }
        }

        private static void ProbarCertificado()
        {
            Crud<Certificado>.EndPoint = "https://localhost:7216/api/Certificados";

            // Crear un objeto de la clase Certificado
            var certificado = Crud<Certificado>.Create(new Certificado
            {
                Id = 0,   // para crear un registro nuevo
                Nombre = "Ana",
                Apellido = "Martinez",
                Fecha = "2023-10-10",
                NombreEvento = "Curso Programacion",
                EventoId = 1  // ID del evento asociado
            });

            // Actualizar el Certificado
            certificado.Nombre = "Ana Maria";
            Crud<Certificado>.Update(certificado.Id, certificado);

            // Obtener todos los certificados
            var certificados = Crud<Certificado>.GetAll();

            foreach (var c in certificados)
            {
                Console.WriteLine($"Codigo: {c.Id}, Nombre: {c.Nombre}, Apellido: {c.Apellido}, Evento: {c.NombreEvento}, Fecha: {c.Fecha}");
            }
        }

        private static void ProbarEspacio()
        {
            Crud<Espacio>.EndPoint = "https://localhost:7216/api/Espacios";

            // Crear un objeto de la clase Espacio
            var espacio = Crud<Espacio>.Create(new Espacio
            {
                Id = 0,   // para crear un registro nuevo
                Nombre = "Auditorio Principal",
                Horario = "08:00 - 12:00"
            });

            // Actualizar el Espacio
            espacio.Nombre = "Auditorio Central";
            Crud<Espacio>.Update(espacio.Id, espacio);

            // Obtener todos los espacios
            var espacios = Crud<Espacio>.GetAll();

            foreach (var e in espacios)
            {
                Console.WriteLine($"Codigo: {e.Id}, Nombre: {e.Nombre}, Horario: {e.Horario}");
            }
        }

        private static void ProbarInscripcion()
        {
            Crud<Inscripcion>.EndPoint = "https://localhost:7216/api/Inscripciones";

            // Crear un objeto de la clase Inscripcion
            var inscripcion = Crud<Inscripcion>.Create(new Inscripcion
            {
                Id = 0,   // para crear un registro nuevo
                FechaInscripcion = "2023-10-01",
                NombreParticipante = "Juan Perez",
                EstadoInscripcion = "Confirmada",
                EventoId = 1 // ID del evento relacionado
            });

            // Actualizar la Inscripcion
            inscripcion.EstadoInscripcion = "Cancelada";
            Crud<Inscripcion>.Update(inscripcion.Id, inscripcion);

            // Obtener todas las inscripciones
            var inscripciones = Crud<Inscripcion>.GetAll();

            foreach (var i in inscripciones)
            {
                Console.WriteLine($"Codigo: {i.Id}, Nombre: {i.NombreParticipante}, Estado: {i.EstadoInscripcion}, EventoId: {i.EventoId}");
            }
        }

        private static void ProbarPago()
        {
            Crud<Pago>.EndPoint = "https://localhost:7216/api/Pagos";

            // Crear un objeto de la clase Pago
            var pago = Crud<Pago>.Create(new Pago
            {
                Id = 0,   // para crear un registro nuevo
                FechaPago = "2023-10-01",
                Monto = 150.00,
                MetodoPago = "Tarjeta de Crédito",
                InscripcionId = 5  // ID de la inscripción asociada
            });

            // Actualizar el Pago
            pago.Monto = 200.00; // Cambiar el monto del pago
            Crud<Pago>.Update(pago.Id, pago);

            // Obtener todos los pagos
            var pagos = Crud<Pago>.GetAll();

            foreach (var p in pagos)
            {
                Console.WriteLine($"Codigo: {p.Id}, FechaPago: {p.FechaPago}, Monto: {p.Monto}, MetodoPago: {p.MetodoPago}");
            }
        }
    }
}
